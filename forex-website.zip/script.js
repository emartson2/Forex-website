document.addEventListener("DOMContentLoaded", function () {
    const forexData = document.getElementById("forex-data");
    forexData.innerHTML = "Fetching real-time Forex data...";
    
    // Simulate fetching market data
    setTimeout(() => {
        forexData.innerHTML = "<p>EUR/USD: 1.1050 | GBP/USD: 1.3050 | USD/JPY: 145.25</p>";
    }, 2000);
});
